
public class MyHW2Tester {

	public static void main(String[] args){
		HW2BitVector bv = new HW2BitVector();
		bv.set(2);
	}
}
